//
// generator.hpp
// ~~~~~~~~~~~~~
// Implementation of a type-erased generator.
//
// Copyright (c) 2015 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef RESUMABLE_EXPRESSIONS_GENERATOR_HPP
#define RESUMABLE_EXPRESSIONS_GENERATOR_HPP

#include <cassert>
#include <exception>
#include <memory>
#include <type_traits>
#include "rexp/resumable.hpp"

namespace rexp {

class stop_generation : std::exception {};

namespace detail
{
  template <class T>
  struct generator_impl_base
  {
    virtual ~generator_impl_base() {}
    virtual T& next() = 0;
    virtual T& current() = 0;
  };

  template <class T, class G>
  struct generator_impl
    : generator_impl_base<T>
  {
    generator_impl(G g) :
      generator_(g),
      r_([this]
          {
            generator_(
              [v = &value_](T next)
              {
                *v = next;
                break_resumable;
              });
          })
    {
    }

    virtual T& next()
    {
      r_.resume();
      if (r_.ready())
        throw stop_generation();
      return value_;
    }

    virtual T& current()
    {
      return value_;
    }

    G generator_;
    T value_;
    resumable_object<void> r_;
  };
}

template <class T> class generator;

template<typename value_t>
struct generator_iterator : public std::iterator
<
  std::input_iterator_tag,   // iterator_category
  value_t,                   // value_type
  size_t,                    // difference_type
  value_t*,                  // pointer
  value_t&                   // reference
>
{
public:
  generator_iterator(generator<value_t>& generator)
  : _generator{&generator}
  {
    next();
  }
  generator_iterator()
  : _generator{0}
  {}

  generator_iterator& operator++()
  {
    next();
    return *this;
  }
  
  generator_iterator operator++(int) 
  {
    next();
    return *this;
  }
  
  bool operator==(const generator_iterator& other) const 
  {
    return _generator == 0 && other._generator == 0;
  }
  
  bool operator!=(const generator_iterator& other) const 
  {
    return !(*this == other);
  }
  
  value_t& operator*() const 
  {
    return _generator->current();
  }
private:
  void next()
  {
    if (_generator)
    {
      try
      {
        _generator->next();
      }
      catch(stop_generation&)
      {
        _generator = 0;
      }
    }
  }
  generator<value_t>* _generator;
};

template <class T>
class generator
{
public:
  typedef generator_iterator<T> iterator;
  iterator begin() {return iterator{*this};}
  iterator end() {return iterator{};}
  template <class G>
  generator(G g)
    : impl_(std::make_shared<
        detail::generator_impl<T, G>>(std::move(g))) {}

  template <class G, class Allocator>
    generator(std::allocator_arg_t, const Allocator& a, G g)
      : impl_(std::allocate_shared<
          detail::generator_impl<T, G>>(a, std::move(g)))
    {
    }

  T& next() { return impl_->next(); }

  T& current() { return impl_->current(); }

private:
  std::shared_ptr<detail::generator_impl_base<T>> impl_;
};

} // namespace rexp

#endif // RESUMABLE_EXPRESSIONS_GENERATOR_HPP
