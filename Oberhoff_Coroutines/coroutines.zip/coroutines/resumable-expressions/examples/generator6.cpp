
#include "rexp/resumable.hpp"
#include "rexp/generator.hpp"

#include <boost/range/iterator_range.hpp>

#include <iostream>
#include <iterator>

using rexp::generator;
using rexp::generator_iterator;

generator<int> fib()
{
  return {
    [=](auto yield) mutable
    {
      int a = 0;
      int b = 1;
      while (true)
      {
        yield(a);
        auto next = a + b;
        a = b;
        b = next;
      }
    }
  };
}


int main()
{
  generator<int> g = fib();
  for (auto value : g)
  {
    std::cout << value << std::endl;
  }
}
